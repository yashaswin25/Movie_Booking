﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Theater
{
    public class BookingTicket
    {
        public SeatDetails Details { get; set; }
        public int TicketNumber { get; set; }

        public BookingTicket(SeatDetails details)
        {
            Details = details;
        }
    }
}

