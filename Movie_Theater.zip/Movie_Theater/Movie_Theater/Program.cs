﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Theater
{
    class Program
    {
        static void Main(string[] args)
        {           
            while (true)
            {
                Console.WriteLine("MAIN MENU:");
                Console.WriteLine("1. Initialize a theater.");
                Console.WriteLine("2. See current seat occupancy details.");
                Console.WriteLine("3. Book a seat and issue a ticket.");
                Console.WriteLine("4. Cancel a booking.");
                Console.WriteLine("5. Exit");
                int choice = ManageTheater.GetValidNumber("Enter your choice: ");
                if (choice == 1)
                {
                    String correctEmail = "xyz@gmail.com";
                    var correctPassword = "Xyz@123";
                    Console.WriteLine("Enter Email");
                    String email = Console.ReadLine();
                    Console.WriteLine("Enter Password");
                    var password = Console.ReadLine();
                    if (email == correctEmail && password == correctPassword)
                    {
                        Console.WriteLine("Welcome Admin");
                        ManageTheater.InitializeTheater();
                    }
                    
                }
                else if (choice == 2)
                {
                    ManageTheater.DisplayOccupancy();
                }
                else if (choice == 3)
                {
                    ManageTheater.HandleBooking();
                }
                else if (choice == 4)
                {
                    ManageTheater.HandleCancellation();
                }
                else if (choice == 5)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                }
            }
        }
    }
}