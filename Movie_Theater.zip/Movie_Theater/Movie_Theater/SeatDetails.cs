﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Theater
{
    public class SeatDetails
    {
        public int SeatNumber { get; set; }
        public bool IsOccupied { get; set; }
        public string CustomerName { get; set; }
        public string MovieName { get; set; }
        public DateTime ShowTime { get; set; }
        public SeatType SeatType { get; set; }
        public static List<Seat> RegularSeats { get; set; }
        public static List<Seat> PremiumSeats { get; set; }
        public static List<Seat> VIPSeats { get; set; }
        public int TicketNumber { get; set; }
       

    }
    public enum SeatType
    {
        Regular = 1,
        Premium,
        VIP
    }
}
