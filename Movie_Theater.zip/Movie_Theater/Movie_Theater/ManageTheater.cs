﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Theater
{
    public class ManageTheater
    {              
        public static int nextSeatNumber = 1;
        public static void InitializeTheater()
        {
            int regularSeats = GetValidNumber("Enter number of regular seats: ");
            int premiumSeats = GetValidNumber("Enter number of premium seats: ");
            int vipSeats = GetValidNumber("Enter number of VIP seats: ");
            SeatDetails.RegularSeats = InitializeSeats(regularSeats, SeatType.Regular);
            SeatDetails.PremiumSeats = InitializeSeats(premiumSeats, SeatType.Premium);
            SeatDetails.VIPSeats = InitializeSeats(vipSeats, SeatType.VIP);
        }

        public static List<Seat> InitializeSeats(int numberOfSeats, SeatType seatType)
        {
            var seats = new List<Seat>();
            for (int i = 1; i <= numberOfSeats; i++)
            {
                seats.Add(new Seat(nextSeatNumber++, seatType));
            }
            return seats;
        }

        public static void DisplayOccupancy()
        {
            Console.WriteLine("Regular Seats:");
            foreach (var seat in SeatDetails.RegularSeats)
            {
                string status = seat.Details.IsOccupied ? "Occupied" : "Available";
                Console.WriteLine($"Seat {seat.Details.SeatNumber}: {status}");
            }
            Console.WriteLine("Premium Seats:");
            foreach (var seat in SeatDetails.PremiumSeats)
            {
                string status = seat.Details.IsOccupied ? "Occupied" : "Available";
                Console.WriteLine($"Seat {seat.Details.SeatNumber}: {status}");
            }
            Console.WriteLine("VIP Seats:");
            foreach (var seat in SeatDetails.VIPSeats)
            {
                string status = seat.Details.IsOccupied ? "Occupied" : "Available";
                Console.WriteLine($"Seat {seat.Details.SeatNumber}: {status}");
            }
        }

        public static void HandleBooking()
        {
            while (true)
            {
                Console.WriteLine("Select seat type:");
                foreach (SeatType type in Enum.GetValues(typeof(SeatType)))
                {
                    Console.WriteLine($"{(int)type}. {type}");
                }
                Console.WriteLine("4. Back");

                int typeNumber = GetValidNumber("Enter the number corresponding to seat type: ");
                if (typeNumber == 4)
                {
                    return;
                }
                if (!Enum.IsDefined(typeof(SeatType), typeNumber))
                {
                    Console.WriteLine("Invalid seat type. Please enter a valid number");
                    continue;
                }

                SeatType seatType = (SeatType)typeNumber;
                List<Seat> availableSeats = GetSeatsByType(seatType);

                while (true)
                {
                    Console.Write("Enter seat number (or press (0) to back): ");
                    string input = Console.ReadLine();
                    if (input == "0")
                    {
                        break;
                    }

                    if (int.TryParse(input, out int seatNumber))
                    {
                        var selectedSeat = availableSeats.FirstOrDefault(s => s.Details.SeatNumber == seatNumber);

                        if (selectedSeat == null)
                        {
                            Console.WriteLine($"Invalid seat number for {seatType} class.");
                        }
                        else if (selectedSeat.Details.IsOccupied)
                        {
                            Console.WriteLine($"Seat {seatNumber} is already occupied.");
                        }
                        else
                        {
                            Console.WriteLine($"Enter customer name for seat {seatNumber}: ");
                            string customerName = Console.ReadLine();
                            Console.WriteLine($"Enter movie name for seat {seatNumber}: ");
                            string movieName = Console.ReadLine();
                            Console.WriteLine($"Enter show time for seat {seatNumber}: ");
                            DateTime showTime;
                            while (true)
                            {
                                bool check = DateTime.TryParse(Console.ReadLine(), out showTime);
                                if (!check)
                                {
                                    Console.WriteLine("Please enter a valid date.");
                                    continue;
                                }
                                break;
                            }
                            var ticket = DisplayTicketAndCancel.BookSeat(selectedSeat, customerName, movieName, showTime);
                            if (ticket != null)
                            {
                                Console.WriteLine($"Booking successful for Seat {seatNumber} customer: {customerName} for movie {movieName} on {showTime}!");
                                Console.WriteLine($"Your ticket number is: {ticket.TicketNumber}");
                            }
                            else
                            {
                                Console.WriteLine("Failed to book seat.");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a valid seat number.");
                    }
                }
            }
        }

        public static List<Seat> GetSeatsByType(SeatType seatType)
        {
            switch (seatType)
            {
                case SeatType.Regular:
                    return SeatDetails.RegularSeats;
                case SeatType.Premium:
                    return SeatDetails.PremiumSeats;
                case SeatType.VIP:
                    return SeatDetails.VIPSeats;
                default:
                    return null;
            }
        }

        public static void HandleCancellation()
        {
            while (true)
            {
                Console.Write("Enter ticket number to cancel (or press (0) to back): ");
                string input = Console.ReadLine();
                if (input == "0")
                {
                    break;
                }

                if (int.TryParse(input, out int ticketNumber))
                {
                    bool success = DisplayTicketAndCancel.CancelBookingByTicket(GetAllSeats(), ticketNumber);
                    if (!success)
                    {
                        Console.WriteLine("Invalid ticket number or ticket not found.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid ticket number.");
                }
            }
        }

        public static List<Seat> GetAllSeats()
        {
            var allSeats = new List<Seat>();
            allSeats.AddRange(SeatDetails.RegularSeats);
            allSeats.AddRange(SeatDetails.PremiumSeats);
            allSeats.AddRange(SeatDetails.VIPSeats);
            return allSeats;
        }

        public static int GetValidNumber(string prompt)
        {
            int number;
            while (true)
            {
                Console.Write(prompt);
                if (int.TryParse(Console.ReadLine(), out number) && number > 0)
                {
                    return number;
                }
                Console.WriteLine("Invalid input. Please enter a valid number.");
            }
        }
    }
}
