﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movie_Theater
{
    public class Seat
    {
        public SeatDetails Details { get; set; }

        public Seat(int seatNumber, SeatType seatType)
        {
            Details = new SeatDetails
            {
                SeatNumber = seatNumber,
                SeatType = seatType,
                IsOccupied = false
            };
        }
    }
}
