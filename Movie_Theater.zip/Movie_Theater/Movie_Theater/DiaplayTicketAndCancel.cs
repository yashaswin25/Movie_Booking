﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Movie_Theater
{
    public class DisplayTicketAndCancel
    {
        public static Random random = new Random();
        public static BookingTicket BookSeat(Seat seat, string customerName, string movieName, DateTime showTime)
        {
            if (!seat.Details.IsOccupied)
            {
                seat.Details.IsOccupied = true;
                seat.Details.CustomerName = customerName;
                seat.Details.MovieName = movieName;
                seat.Details.ShowTime = showTime;
                seat.Details.TicketNumber = random.Next(100, 500); 

                var ticket = new BookingTicket(seat.Details)
                {
                    TicketNumber = seat.Details.TicketNumber
                };

                return ticket;
            }
            return null;
        }

        public static bool CancelBookingByTicket(List <Seat> seats, int ticketNumber)
        {
            foreach (var seat in seats)
            {
                if (seat.Details.TicketNumber == ticketNumber)
                {
                    if (seat.Details.IsOccupied)
                    {
                        seat.Details.IsOccupied = false;
                        Console.WriteLine($"Booking for seat {seat.Details.SeatNumber} has been cancelled.");
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
